/**
* @file MachineVirtuelle.h
* @author Zihui Zhong, Pascal Desrochers
*
* Definition de la classe MachineVirtuelle
*/

#ifndef _MACHINE_VIRTUELLE_H
#define _MACHINE_VIRTUELLE_H

class MachineVirtuelle
{
public:
	MachineVirtuelle(const int nid, const int cpuRequis);
	MachineVirtuelle(const MachineVirtuelle& ma);
	~MachineVirtuelle();
	
	virtual void afficher();
	virtual MachineVirtuelle& operator=(const MachineVirtuelle& app);
	virtual bool operator== (const MachineVirtuelle& hpc) const;
	int getNid() const;
	int getCpuRequis() const;
	int getCpuRestant() const ;
	
	void setNid(int nid);
	void setCpuRequis(int cpuRequis);
	void setCpuRestant(int cpuRestant);
private:
	int nid_;
	int cpuRequis_;
	int cpuRestant_;



};

#endif