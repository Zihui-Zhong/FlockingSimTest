/**
* @file Application.cpp
* @author Zihui Zhong, Pascal Desrochers
*
* Implementation de la classe Application
*/

#include "Application.h"
#include <iostream>

using namespace std;

Application::Application(){

}
int Application::getNid() const{
	return nid_;
}
string Application::getNom() const{
	return nom_;
}
int Application::getCapRequis() const{
	return capRequis_;
}

void Application::setNid(const int n){
	nid_ = n;
}
void Application::setNom(const string& n){
	nom_ = n;
}
void Application::setCapRequis(const int cr){
	capRequis_ = cr;
}

/**
* Affiche les informations de l'application
*/
void Application::afficher() const
{
	cout<<"-------------Application-------------"<<endl;
	cout<<"nid :"<< nid_ <<endl;
	cout<<"Nom:"<<nom_ <<endl;
	cout<<"-------------------------------------"<<endl;
}

bool Application::operator== (const Application& app) const
{
	return nid_ == app.nid_;
}

