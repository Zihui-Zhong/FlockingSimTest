/**
* @file Cloud.cpp
* @author Zihui Zhong, Pascal Desrochers
*
* Implementation de la classe Cloud
*/


#include "Application.h"
#include "MachineVirtuelle.h"
#include "ServeurPhysique.h"
#include "Cloud.h"
#include <iostream>
#include <vector>

using namespace std;


//Aucune indication sur la taille CPU des serveurs physiques et des machines virtuelles, Valeurs Arbitraire
const int PHYSICAL_SERVER_CAPACITY=50;
const int VIRTUAL_MACHINE_CAPACITY=25;

Cloud::Cloud(const int nbServeurPhysique,const int nbMachineVirtuelle){

	for(int i=0; i<nbServeurPhysique;i++){
		ServeurPhysique* temp = new ServeurPhysique(i,PHYSICAL_SERVER_CAPACITY);
		listeSPs_.push_back(temp);
	}
	for(int i=0; i<nbMachineVirtuelle;i++){
		MachineVirtuelle* temp = new MachineVirtuelle(i,VIRTUAL_MACHINE_CAPACITY);
		listeMVs_.push_back(temp);
	}
}
Cloud::~Cloud(void){
	for(int i=0; i<listeSPs_.size();i++){
		delete listeSPs_[i];
	}

}
/**
* Affiche les informations de tout les serveurs physiques et Machine virtuelles sur le cloud
* @param cloud
*/
ostream& operator<< (ostream& os, const Cloud& cloud) {
	for(int i=0; i<cloud.listeSPs_.size();i++){
		(cloud.listeSPs_[i])->afficher();
	}

	return os;
}

/**
* Demande l'information sur la connection physique des serveurs
* @param cloud
*/
istream& operator>> (istream& is, const Cloud& cloud){
	for(int i=0; i<cloud.listeSPs_.size();i++){
		for(int j=1+i;j<cloud.listeSPs_.size();j++){
			int k;
			cout<<endl<<"Nombre de hop entre la machine physique "<< i<<" et la machine physique "<<j<<":";
			cin>>k;
			cloud.listeSPs_[i]->connecterMP(j,k);
			cloud.listeSPs_[j]->connecterMP(i,k);
		}
	}
	return is;
}

/**
* Distribue les machine virtuelles du cloud parmis tout les serveurs physique du cloud
*
*/
void Cloud::ordonnancerMV(){
	bool deployed= false;
	for(int i =0;i<listeMVs_.size();i++){
		
		for(int j=0;j<listeSPs_.size()&&(!deployed);j++){
			if(listeSPs_[j]->deployerMV(listeMVs_[i])){
				deployed=true;
			}
		}
		if(!deployed){
			cout<<"Machine virtuel ID:"<<listeMVs_[i]->getNid()<<" impossible a deployer DELETED";
			delete listeMVs_[i];
			listeMVs_.erase(listeMVs_.begin()+i);
			i--;
		}

		deployed=false;
	}
}
/**
* Deploie un vecteur d'application sur les machines virtuelles du cloud
*
* @param applications vecteur d'applications a deployer
*/
void Cloud::deployerApplication(vector<Application*> applications){
	bool deployed= false;
	for(int i =0;i<applications.size();i++){

		for(int j=0;j<listeMVs_.size()&&(!deployed);j++){
			if(applications[i]->deployerSurMV(*listeMVs_[j])){
				deployed=true;
			}
		}

		if(!deployed){
			cout<<"Application :"<<applications[i]->getNom()<<" impossible a deployer DELETED";
			applications.erase(applications.begin()+i);
			i--;
		}

		deployed=false;
	}
}