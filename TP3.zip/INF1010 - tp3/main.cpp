/**
* @file Main.cpp
* @author Zihui Zhong, Pascal Desrochers
*
* Implementation de la classe Main
*/


#include "Application.h"
#include "MachineVirtuelle.h"
#include "ServeurPhysique.h"
#include "VideoSurDemande.h"
#include "Cloud.h"
#include "HPC.h"
#include <iostream>


using namespace std;


int main()
{	


	/*
	1: Créer une application VideoSurDemande vsd1 à partir du constructeur par parametre. Cette application aura pour id 0, pour nom 'Vidéo sur demande 1' et pour
	capacité requise 10.
	*/
	VideoSurDemande vsd1(0,"Video sur demande 1",10);


	/*
	2: Créer une application VideoSurDemande vsd2 à partir du constructeur par parametre. Cette application aura pour id 1, pour nom 'Vidéo sur demande 2' et pour
	capacité requise 20.
	*/

	VideoSurDemande vsd2(1,"Video sur demande 2", 20);

	/*
	3: Créer une application HPC hpc à partir du constructeur par parametre. Cette application aura pour id 2, pour nom 'High Performance Computing'.Elle aura besoin pour fonctionner de
	3 Machine virtuelle
	*/

	HPC hpc(2,"High Performance Computing",3);
	//Valeur Arbritraire pour cap de hpc, non specifie dans l'enonce
	hpc.setCapRequis(50);
	/*
	4:Afficher les trois applications créées
	*/
	vsd1.afficher();
	vsd2.afficher();
	hpc.afficher();



	/*
	5: Créer un objet vector<Application*> applis et y insérer les trois applications précédemment créées
	*/
	vector<Application*> applis;
	applis.push_back(&vsd1);
	applis.push_back(&vsd2);
	applis.push_back(&hpc);

	/*
	6: Créer un objet Cloud cloud, contenant 5 serveurs physiques et 4 machines virtuelles
	*/

	Cloud a(5,4);


	/*
	7: Interconnecter les différentes machines physique à l'aide de l'opérateur redéfini >>
	*/
	cin>>a;


	/*

	8: Déployer l'ensemble des machines virtuelles sur les serveurs physiques
	*/

	a.ordonnancerMV();



	/*
	9: Déployer les différentes applications sur les machines physiques
	*/

	a.deployerApplication(applis);

	/*
	10: Afficher le réseau cloud
	*/
	cout<<a;


	return 0;
}
