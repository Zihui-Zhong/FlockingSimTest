/**
* @file MachineVirtuelle.cpp
* @author Zihui Zhong, Pascal Desrochers
*
* Implementation de la classe MachineVirtuelle
*/

#include "MachineVirtuelle.h"
#include <iostream>


using namespace std;

MachineVirtuelle::MachineVirtuelle(const int nid, const int cpuRequis){
	nid_=nid;
	cpuRequis_=cpuRequis;
	cpuRestant_=cpuRequis*0.9;
}
MachineVirtuelle::MachineVirtuelle(const MachineVirtuelle& ma){
	nid_=ma.nid_;
	cpuRequis_=ma.cpuRequis_;
	cpuRestant_=ma.cpuRestant_;
}
MachineVirtuelle::~MachineVirtuelle(){

}

/**
* Affiche les informations de la MachineVirtuelle
*/
void MachineVirtuelle::afficher(){
	cout<<"-------------Machine virtuelle-------------"<<endl;
	cout<<"Id :"<<nid_<<endl;
	cout<<"Cpu Requis:"<<cpuRequis_<<endl;
	cout<<"Cpu Restant:"<<cpuRestant_<<endl;
	cout<<"-------------------------------------"<<endl;
}
MachineVirtuelle& 	MachineVirtuelle::operator=(const MachineVirtuelle& app){
	if(this!=&app){
		nid_= app.nid_;
		cpuRequis_= app.cpuRequis_;
		cpuRestant_=app.cpuRestant_;
	}
	return *this;
}
bool MachineVirtuelle::operator== (const MachineVirtuelle& hpc) const{

	return nid_==hpc.getNid();

}

int MachineVirtuelle::getNid() const{
	return nid_;
}
int MachineVirtuelle::getCpuRequis() const{
	return cpuRequis_;
}
int MachineVirtuelle::getCpuRestant() const{
	return cpuRestant_;
}

void MachineVirtuelle::setNid(int nid){
	nid_=nid;
}

void MachineVirtuelle::setCpuRequis(int cpuRequis){
	cpuRequis_=cpuRequis;
}
void MachineVirtuelle::setCpuRestant(int cpuRestant){
	cpuRestant_=cpuRestant;
}