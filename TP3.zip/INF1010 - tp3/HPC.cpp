/**
* @file HPC.cpp
* @author Zihui Zhong, Pascal Desrochers
*
* Implementation de la classe HPC
*/

#include "HPC.h"
#include "Application.h"
#include <iostream>
#include <vector>

using namespace std;

HPC::HPC(const int nid, const string& nom, const int nbMVRequis)
{
	setNid(nid);
	setNom(nom);
	nbMVRequis_= nbMVRequis;
	nbMVActuel_=0;
}

HPC::HPC(const HPC& hpc)
{
	setNid(hpc.getNid());
	setNom(hpc.getNom());
	setCapRequis(hpc.getCapRequis());

	nbMVRequis_ = hpc.getNbMVRequis();
	nbMVActuel_= hpc.getNbMVActuel();

	for(int i=0; i<hpc.mvs_.size(); i++)
		mvs_[i] = new MachineVirtuelle(*hpc.mvs_[i]);
}

HPC::~HPC(){
	//Ce sont les serveurs physiques qui delete les machines Virtuelle, non les applications

}

int HPC::getNbMVRequis() const{
	return nbMVRequis_;
}
int HPC::getNbMVActuel() const{
	return nbMVActuel_;
}
MachineVirtuelle* HPC::getMVS(int index) const{
	return mvs_[index];
}

void HPC::setNbMVRequis(const int n){
	nbMVRequis_ = n;
}
void HPC::setNbMVActuel(const int n){
	nbMVActuel_ = n;
}
void HPC::setMVS( MachineVirtuelle mvs, int index){
	mvs_[index] = &mvs;
}

/**
* Affiche les informations de l'application
*/
void HPC::afficher() const{
	cout<<"-------------Application HPC-------------"<<endl;
	cout<<"nid :"<< getNid() <<endl;
	cout<<"Nom:"<<getNom() <<endl;
	cout<<"Nombre de VM Requis :"<<nbMVRequis_<<endl;
	cout<<"Nombre de VM Actuel :"<<nbMVActuel_<<endl;
	for(int i = 0 ; i< mvs_.size(); i++){
		cout<<"     VM de ID:"<<mvs_[i]->getNid()<<endl;
	}
	cout<<"-------------------------------------"<<endl;
}

/**
*  Deploie le HPC sur machine virtuelle
*
* @param mv MachineVirtuelle a deployer
* @return retourne vrai si le HPC a ete deployer et a atteint son capRequis
*/
bool HPC::deployerSurMV(MachineVirtuelle& mv){
	for(int i=0; i<nbMVActuel_; i++)
		if(*mvs_[i] == mv)
			return false;

	if(nbMVActuel_+1==nbMVRequis_){

		//Calaulation of cpu in all of the Virtual machines
		int currentCpu=0;
		for(int i=0; i<nbMVActuel_; i++)
			currentCpu+=mvs_[i]->getCpuRestant();
		currentCpu+=mv.getCpuRestant();


		if(currentCpu>getCapRequis()){

			mvs_.push_back(&mv);
			nbMVActuel_++;

			//Distribution du cap requis dans tous le virtual machines
			currentCpu=getCapRequis();
			for(int i=0;i<nbMVActuel_;i++){
				if(mvs_[i]->getCpuRestant()<currentCpu){
					currentCpu-=mvs_[i]->getCpuRestant();
					mvs_[i]->setCpuRestant(0);
				}else{
					mvs_[i]->setCpuRestant(mvs_[i]->getCpuRestant()-currentCpu);
					return true;
				}
			}


		}else{
			//Elimination de la machine virtuelle avec le moins de CPU
			int lowestIndex=0;
			for(int i=1;i<nbMVActuel_;i++){
				if(mvs_[i]->getCpuRestant()<mvs_[lowestIndex]->getCpuRestant()){
					lowestIndex=i;
				}
			}
			if(mvs_[lowestIndex]->getCpuRestant()<mv.getCpuRestant()){
				mvs_[lowestIndex]=&mv;
			}

		}

	}else{
		mvs_.push_back(&mv);
		nbMVActuel_++;
	}


	return false;

}


HPC& HPC::operator=(const HPC& hpc){
	if(this != &hpc){
		setNid(hpc.getNid());
		setNom(hpc.getNom());
		setCapRequis(hpc.getCapRequis());

		nbMVRequis_ = hpc.getNbMVRequis();
		nbMVActuel_= hpc.getNbMVActuel();

		for(int i=0; i < mvs_.size(); i++){
			if(mvs_[i] != 0){
				delete mvs_[i];
				mvs_[i]=hpc.getMVS(i); 
			}
		}

	}
	return *this;

}

bool HPC::operator== (const HPC& hpc) const
{
	return getNid() == hpc.getNid();
}



