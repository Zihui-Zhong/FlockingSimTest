/**
* @file HPC.h
* @author Zihui Zhong, Pascal Desrochers
*
* Definition de la classe HPC
*/

#ifndef _HPC_H_
#define _HPC_H_

#include "MachineVirtuelle.h"
#include "Application.h"
#include <vector>

class HPC : public Application
{
public:

	HPC(const int nid, const std::string& nom, const int nbMVRequis);
	HPC(const HPC& hpc);
	~HPC();

	int getNbMVRequis() const;
	int getNbMVActuel() const;
	MachineVirtuelle* getMVS(int index) const;

	void setNbMVRequis(const int n);
	void setNbMVActuel(const int n);
	void setMVS( MachineVirtuelle mvs, int index);

	virtual HPC& operator=(const HPC& hpc);
	virtual bool operator== (const HPC& hpc) const;

	virtual void afficher() const;
	virtual bool deployerSurMV(MachineVirtuelle& mv);

private:
	int nbMVRequis_;
	int nbMVActuel_;
	std::vector<MachineVirtuelle*> mvs_;
};

#endif