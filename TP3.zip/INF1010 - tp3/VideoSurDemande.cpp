/**
* @file VideoSurDemande.cpp
* @author Zihui Zhong, Pascal Desrochers
*
* Implementation de la classe VideoSurDemande
*/

#include "VideoSurDemande.h"	
#include <string>
#include <iostream>
#include <string>

using namespace std;

VideoSurDemande::VideoSurDemande(const int nid, const string& nom, const int capRequis)
{
	setNid(nid);
	setNom(nom);
	setCapRequis(capRequis);
	mv_=0;
	deployed = false;
}

VideoSurDemande::VideoSurDemande(const VideoSurDemande& vsd)
{
	setNid(vsd.getNid());
	setNom(vsd.getNom());
	setCapRequis(vsd.getCapRequis());

	mv_ = new MachineVirtuelle(*(vsd.getMachineVirtuelle()));
}

VideoSurDemande::~VideoSurDemande()
{
		//Ce sont les serveurs physiques qui delete les machines Virtuelle, non les applications


}

MachineVirtuelle* VideoSurDemande::getMachineVirtuelle() const
{
	return mv_;
}
void VideoSurDemande::setMachineVirtuelle(MachineVirtuelle* mv)
{
	mv_ = mv;
}

/**
* Affiche les informations d'un video sur demande 
*/
void VideoSurDemande::afficher() const
{
	cout<<"-------------Application-------------"<<endl;
	cout<<"nid :"<< getNid() <<endl;
	cout<<"Nom:"<<getNom() <<endl;
	if(deployed){
		cout<<"Deploye sur la machine virtuelle ID:"<<mv_->getNid()<<endl;
	}
	cout<<"-------------------------------------"<<endl;
}
/**
* Deploie une video sur demande sur une machine virtuelle
*
* @param mv machine virtuelle sur laquelle la video va etre deploye
* @return retourne vrai si la machine virtuelle avait assez de cpu pour deployer la video
*/
bool VideoSurDemande::deployerSurMV(MachineVirtuelle& mv)
{
	if (mv.getCpuRestant()>getCapRequis()){
		mv_=&mv;
		mv.setCpuRestant(mv.getCpuRestant()-getCapRequis());
		deployed= true;
		return true;

	}
	return false;
}

VideoSurDemande& VideoSurDemande::operator=(const Application& app)
{
	if(this!=&app){
		setNid(app.getNid());
		setCapRequis(app.getCapRequis());
		setNom(app.getNom());

	}
	return *this;
}
bool VideoSurDemande::operator==(const Application& app) const
{
	return getNid() == app.getNid();
}