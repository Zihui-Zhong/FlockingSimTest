/**
* @file ServeurPhysique.cpp
* @author Zihui Zhong, Pascal Desrochers
*
* Implementation de la classe ServeurPhysique
*/

#include "ServeurPhysique.h"
#include "MachineVirtuelle.h"
#include <iostream>
#include <list>
using namespace std;

ServeurPhysique::ServeurPhysique(int nid, int cpu)
{
	nid_=nid;
	cpu_=cpu;
	cpuRestant_=cpu;
	nbConnexion_=0;
	nbMVs_=0;

}
ServeurPhysique::~ServeurPhysique()
{
	for(int i=0; i<mvs_.size(); i++)
		delete mvs_[i];
}

int ServeurPhysique::getNid() const{
	return nid_;
}
int ServeurPhysique::getCpu() const{
	return cpu_;
}
int ServeurPhysique::getCpuRestant() const{
	return cpuRestant_;
}
int ServeurPhysique::getNbConnexion() const{
	return nbConnexion_;
}
vector<int> ServeurPhysique::getEnsMP() const{
	return ensMP_;
}
int ServeurPhysique::getNbMVs() const{
	return nbMVs_;
}
vector<MachineVirtuelle*> ServeurPhysique::getMVS() const{
	return mvs_;
}
vector<int> ServeurPhysique::getEnsSaut() const{
	return ensSaut_;
}

void ServeurPhysique::setNid(const int n){
	nid_ =n;
}
void ServeurPhysique::setCPU(const int c){
	cpuRestant_= c;
}
void ServeurPhysique::setCPURestant(const int c){
	cpuRestant_ = c;
}
void ServeurPhysique::setNbConnexion(const int nc){
	nbConnexion_ = nc;
}
void ServeurPhysique::setEnsMP(const int index, const int mp){
	ensMP_[index] = mp;
}
void ServeurPhysique::setMVS(const int index, MachineVirtuelle* mv){
	mvs_[index] = mv;
}
void ServeurPhysique::setEnsSaut(int index, int s){
	ensSaut_[index]= s;
}

/**
* Connecte le serveur physique a un autre serveur physique
*
* @param nid nid de l'autre serveur physique
* @param saut saut de l'autre serveur
*/
void ServeurPhysique::connecterMP(const int nid,const int saut)
{
	if(saut>0){
		ensMP_.push_back( nid);
		ensSaut_.push_back(saut);
		nbConnexion_++;
	}
}

/**
* Verifie si le serveur est connecte a un autre serveur en particulier
*
* @param nid nid de l'autre serveur
* @return retourne vrai s'il est connecte avec l'autre serveur
*/
bool ServeurPhysique::estConnecte(int nid) const
{
	for(int i=0; i<nbConnexion_; i++)
		if(nid == ensMP_[i])
			return true;

	return false;

}

/**
* Deploie une machine virtuelle sur le serveur
*
* @param mv machine virtuelle a deployer
* @return retourne vrai si le serveur avait assez de cpu restant pour deployer la machine virtuelle
*/
bool ServeurPhysique::deployerMV( MachineVirtuelle* mv)
{
	if(mv->getCpuRequis()<=cpuRestant_){
		cpuRestant_-=mv->getCpuRequis();
		mvs_.push_back(mv);
		nbMVs_++;
		return true;
	}
	return false;
}

/**
* Affiche les informations d'un serveur physique
*
*/
void ServeurPhysique::afficher() const
{
	cout<<"-------------Serveur Physique-------------"<<endl;
	cout<<"nid :"<< nid_ <<endl;
	cout<<"CPU:"<<cpu_ <<endl;
	cout<<"CPU restant:"<<cpuRestant_<<endl;
	cout<<"Nombre de machine virtuelle deployee:"<<nbMVs_<<endl;
	for(int i = 0 ; i< nbMVs_; i++){
		cout<<"     VM de ID:"<<mvs_[i]->getNid()<<endl;
	}
	cout<<"Nombre de connexion:"<<nbConnexion_<<endl;
	for(int i = 0 ; i< nbConnexion_; i++){
		cout<<"     ID machine interconnete:"<<ensMP_[i]<<endl;
		cout<<"     Nombre de saut::"<<ensSaut_[i]<<endl;
	}
	cout<<"-------------------------------------"<<endl;

}

ServeurPhysique& ServeurPhysique::operator=(const ServeurPhysique& sv)
{

	nid_ = sv.nid_;
	cpu_ = sv.cpu_;
	cpuRestant_ = sv.cpuRestant_;
	nbConnexion_ = sv.nbConnexion_;

	if(nbMVs_ != 0){
		for(int i=0; i < mvs_.size(); i++){
			if(mvs_[i] != 0){
				delete mvs_[i];
				mvs_[i]=sv.getMVS()[i]; 
			}
		}
	}
	if(nbConnexion_ != 0){
		for(int i=0; i < ensMP_.size(); i++){
			if(ensMP_[i] != 0){

				ensMP_[i]=sv.getEnsMP()[i];
				ensSaut_[i]=sv.getEnsSaut()[i];
			}
		}
	}
	return *this;
}
bool ServeurPhysique::operator==(const ServeurPhysique& sv) const
{
	return nid_==sv.getNid();
}
