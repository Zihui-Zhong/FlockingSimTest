/**
* @file VideoSurDemande.h
* @author Zihui Zhong, Pascal Desrochers
*
* Definition de la classe VideoSurDemande
*/

#pragma once

#ifndef _VIDEO_SUR_DEMANDE_H_
#define _VIDEO_SUR_DEMANDE_H_

#include "MachineVirtuelle.h"
#include "Application.h"
#include <string>

class VideoSurDemande : public Application
{
public:
	VideoSurDemande(const int nid, const std::string& nom, const int capRequis);
	VideoSurDemande(const VideoSurDemande& vsd);
	~VideoSurDemande();

	MachineVirtuelle* getMachineVirtuelle() const;
	void setMachineVirtuelle(MachineVirtuelle* mv);

	virtual void afficher() const;
	virtual bool deployerSurMV(MachineVirtuelle& mv);

	virtual VideoSurDemande& operator=(const Application& app);
	bool operator==(const Application& app) const;
private:
	MachineVirtuelle* mv_;
	bool deployed;

};

#endif