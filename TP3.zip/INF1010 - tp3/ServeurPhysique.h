/**
* @fileServeurPhysique.h
* @author Zihui Zhong, Pascal Desrochers
*
* Definition de la classe ServeurPhysique
*/

#pragma once

#ifndef _SERVEUR_PHYSIQUE_H_
#define _SERVEUR_PHYSIQUE_H_

#include <vector>
#include "MachineVirtuelle.h"

class ServeurPhysique
{
public:
	ServeurPhysique(const int nid, const int cpu);
	~ServeurPhysique();

	int getNid() const;
	int getCpu() const;
	int getCpuRestant() const;
	int getNbConnexion() const;
	std::vector<int> getEnsMP() const;
	int getNbMVs() const;
	std::vector<MachineVirtuelle*> getMVS() const;

	std::vector<int> getEnsSaut() const;


	void setNid(const int n);
	void setCPU(const int c);
	void setCPURestant(const int c);
	void setNbConnexion(const int nc);
	void setEnsMP(const int index, const int mp);
	void setMVS(const int index, MachineVirtuelle* mv);
	void setEnsSaut(int index, int s);

	void connecterMP(const int nid, const int saut);
	bool deployerMV(MachineVirtuelle* mv);
	bool estConnecte(const int nid) const;

	virtual void afficher() const;
	virtual ServeurPhysique& operator=(const ServeurPhysique& sv);
	virtual bool operator==(const ServeurPhysique& sv) const;

private:
	int nid_;
	int cpu_;
	int cpuRestant_;
	int nbConnexion_;
	std::vector<int> ensMP_;
	int nbMVs_;
	std::vector<MachineVirtuelle*> mvs_;
	std::vector<int> ensSaut_;

};


#endif