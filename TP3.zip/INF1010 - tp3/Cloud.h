/**
* @file Cloud.h
* @author Zihui Zhong, Pascal Desrochers
*
* Definition de la classe Cloud
*/

#ifndef _CLOUD_H_
#define _CLOUD_H_


#include "Application.h"
#include "MachineVirtuelle.h"
#include "ServeurPhysique.h"
#include <vector>
#include <iostream>

using namespace std;

class Cloud
{
public:
	Cloud(const int nbServeurPhysique,const int nbMachineVirtuelle);
	~Cloud(void);
	friend istream& operator>> (istream& is, const Cloud& cloud);
	friend ostream& operator<< (ostream& os, const Cloud& cloud);
	void ordonnancerMV();
	void deployerApplication(vector<Application*> applications);
private :
	vector<MachineVirtuelle *> listeMVs_;
	vector<ServeurPhysique *> listeSPs_;

};

#endif // _CLOUD_H_
