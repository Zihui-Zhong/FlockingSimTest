/**
* @file Application.h
* @author Zihui Zhong, Pascal Desrochers
*
* Definition de la classe Application
*/

#ifndef _APPLICATION_H_
#define _APPLICATION_H_

#include <string>
#include "MachineVirtuelle.h"

class Application
{
public:
	Application();
	int getNid() const;
	std::string getNom() const;
	int getCapRequis() const;

	void setNid(const int n);
	void setNom(const std::string& n);
	void setCapRequis(const int cr);

	virtual void afficher() const;

	virtual bool deployerSurMV(MachineVirtuelle& mv) = 0;

	bool operator== (const Application& app) const;

private:
	int nid_;
	std::string nom_;
	int capRequis_;
};

#endif